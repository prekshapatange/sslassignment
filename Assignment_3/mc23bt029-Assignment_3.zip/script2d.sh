#!/bin/bash
sed '/Linux and MacOS/a MAkefiles are essential for compilation' data1.txt
