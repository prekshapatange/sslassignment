#!/bin/bash
sed '/Linux/d ; /MacOS/d' data1.txt 
