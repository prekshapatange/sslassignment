#!/bin/bash

	sed '5,10s/Make/Makefile/g' data1.txt 
	


