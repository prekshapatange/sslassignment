#!/bin/bash
 grep -w "compilation" data1.txt


